const AWS = require("aws-sdk");
const s3 = new AWS.S3({ useAccelerateEndpoint: false }); // FIXME

const expiryTimeout = 60 * 60;

const randomString = () => Math.random().toString(36).substring(2, 5);

exports.handler = async ({ queryStringParameters }) => {
  const { filename, contentType } = queryStringParameters;
  const key = `${randomString()}/${filename}`;

  const url = s3.getSignedUrl("putObject", {
    Bucket: process.env.BOX_BUCKET,
    Key: key,
    Expires: expiryTimeout,
    ContentType: contentType,
    ACL: "public-read"
  });

  return {
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      key,
      url
    })
  };
};
